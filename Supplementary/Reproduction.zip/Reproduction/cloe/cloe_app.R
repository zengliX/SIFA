rm(list=ls())
args=commandArgs()[7]


######## preparer is used to deal with args ########
source('../preparer.R')
source('../assist_fun.R')
outfile=paste('./',foldername,'/cloe_out.Rdata',sep='') #name of output file
set.seed(myseed)

############################################
####### load packages #####################
############################################
require('cloe')
require('gtools')
require('ggplot2')
require('reshape')

##########################################
####### loading data #####################
##########################################

reads=obs_data$X
reads=apply(reads,2,as.integer)
depth=obs_data$D
depth=apply(depth,2,as.integer)
ci=cloe_input$new(reads,depth,type='targeted') # convert reads and depth into cloe input format

##################################################
################ running cloe ################
################################################
delta_t=0.4
Temperature=1/seq(from=1,by=delta_t,length.out = 5)

start_t=Sys.time()
# try a list of clone numbers
samples_diffK=list()
ct=1
for(nclone in 3:7)
{
cm=sampler_cnn(input = ci,iterations =10000,K=nclone, chains=5, temperatures=Temperature , progress_interval=20)
samples_diffK[[ct]]=cm
ct=ct+1

cat('working on clone number:',nclone,'\n')
}

summary_diffK=lapply(samples_diffK,summarise,burn=.4,method='map')

######################################################
############### model selection ######################
######################################################

cs_chosen=select_model(summary_diffK,solutions = 1,plot = T,path=paste('./',foldername,sep=''))

#############################################
### save file to folder ###################
#############################################

filename=paste('./',foldername,'/cloe_out.Rdata',sep='')
save(cs_chosen,samples_diffK,obs_data,file=filename)

Sys.time()-start_t




