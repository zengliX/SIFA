#######################################################
#### PROCESS COMMANDLINE ARGUMENTS #####################
#######################################################


args=strsplit(args,'-')[[1]][-1]
print(args)

load(args[1]) #load data file
obs_data=get(args[2]) #observed data
foldername=args[3]
myseed=args[4]
dir.create(foldername)

#####################################