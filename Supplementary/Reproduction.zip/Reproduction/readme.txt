# Reproduction instructions for the SIFA paper

All commands are executed in terminal. You need to have R 3.3.2 or later, and related packages installed. For more information please visit https://github.com/zengliX/SIFApackage.

We recommend running the tasks on computing clusters in parallel, since each task will take many hours to accomplish.


I. reproduce simulation results ----------------------------------------------------------------------------------------



- run SIFA on simulation datasets:

cd ./SIFA/
Rscript SIFA_app.R -../simulation_final/simu_K3_dep40_T4/observed.Rdata-Reads-simu_K3_dep40_T4_s23_samples-23 2&> simu_K3_dep40_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K3_dep60_T4/observed.Rdata-Reads-simu_K3_dep60_T4_s23_samples-23 2&> simu_K3_dep60_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K3_dep80_T4/observed.Rdata-Reads-simu_K3_dep80_T4_s23_samples-23 2&> simu_K3_dep80_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K4_dep40_T4/observed.Rdata-Reads-simu_K4_dep40_T4_s23_samples-23 2&> simu_K4_dep40_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K4_dep60_T4/observed.Rdata-Reads-simu_K4_dep60_T4_s23_samples-23 2&> simu_K4_dep60_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K4_dep80_T4/observed.Rdata-Reads-simu_K4_dep80_T4_s23_samples-23 2&> simu_K4_dep80_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K5_dep40_T4/observed.Rdata-Reads-simu_K5_dep40_T4_s23_samples-23 2&> simu_K5_dep40_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K5_dep40_T4_tree2/observed.Rdata-Reads-simu_K5_dep40_T4_tree2_s23_samples-23 2&> simu_K5_dep40_T4_tree2_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K5_dep40_T4_tree3/observed.Rdata-Reads-simu_K5_dep40_T4_tree3_s23_samples-23 2&> simu_K5_dep40_T4_tree3_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K5_dep60_T4/observed.Rdata-Reads-simu_K5_dep60_T4_s23_samples-23 2&> simu_K5_dep60_T4_s23.txt
Rscript SIFA_app.R -../simulation_final/simu_K5_dep80_T4/observed.Rdata-Reads-simu_K5_dep80_T4_s23_samples-23 2&> simu_K5_dep80_T4_s23.txt




- run pyclone on simulation datasets:

Install pyclone from http://compbio.bccrc.ca/software/pyclone/. 

cd ./pyclone/
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K3_dep40_T4/sample1.tsv ../simulation_final/simu_K3_dep40_T4/sample2.tsv ../simulation_final/simu_K3_dep40_T4/sample3.tsv ../simulation_final/simu_K3_dep40_T4/sample4.tsv --working_dir  simu_K3_dep40_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K3_dep60_T4/sample1.tsv ../simulation_final/simu_K3_dep60_T4/sample2.tsv ../simulation_final/simu_K3_dep60_T4/sample3.tsv ../simulation_final/simu_K3_dep60_T4/sample4.tsv --working_dir  simu_K3_dep60_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K3_dep80_T4/sample1.tsv ../simulation_final/simu_K3_dep80_T4/sample2.tsv ../simulation_final/simu_K3_dep80_T4/sample3.tsv ../simulation_final/simu_K3_dep80_T4/sample4.tsv --working_dir  simu_K3_dep80_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K4_dep40_T4/sample1.tsv ../simulation_final/simu_K4_dep40_T4/sample2.tsv ../simulation_final/simu_K4_dep40_T4/sample3.tsv ../simulation_final/simu_K4_dep40_T4/sample4.tsv --working_dir  simu_K4_dep40_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K4_dep60_T4/sample1.tsv ../simulation_final/simu_K4_dep60_T4/sample2.tsv ../simulation_final/simu_K4_dep60_T4/sample3.tsv ../simulation_final/simu_K4_dep60_T4/sample4.tsv --working_dir  simu_K4_dep60_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K4_dep80_T4/sample1.tsv ../simulation_final/simu_K4_dep80_T4/sample2.tsv ../simulation_final/simu_K4_dep80_T4/sample3.tsv ../simulation_final/simu_K4_dep80_T4/sample4.tsv --working_dir  simu_K4_dep80_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K5_dep40_T4/sample1.tsv ../simulation_final/simu_K5_dep40_T4/sample2.tsv ../simulation_final/simu_K5_dep40_T4/sample3.tsv ../simulation_final/simu_K5_dep40_T4/sample4.tsv --working_dir  simu_K5_dep40_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K5_dep40_T4_tree2/sample1.tsv ../simulation_final/simu_K5_dep40_T4_tree2/sample2.tsv ../simulation_final/simu_K5_dep40_T4_tree2/sample3.tsv ../simulation_final/simu_K5_dep40_T4_tree2/sample4.tsv --working_dir  simu_K5_dep40_T4_tree2_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K5_dep40_T4_tree3/sample1.tsv ../simulation_final/simu_K5_dep40_T4_tree3/sample2.tsv ../simulation_final/simu_K5_dep40_T4_tree3/sample3.tsv ../simulation_final/simu_K5_dep40_T4_tree3/sample4.tsv --working_dir  simu_K5_dep40_T4_tree3_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K5_dep60_T4/sample1.tsv ../simulation_final/simu_K5_dep60_T4/sample2.tsv ../simulation_final/simu_K5_dep60_T4/sample3.tsv ../simulation_final/simu_K5_dep60_T4/sample4.tsv --working_dir  simu_K5_dep60_T4_samples --num_iters 10000 --burnin 6000 --seed 23
PyClone run_analysis_pipeline --in_files ../simulation_final/simu_K5_dep80_T4/sample1.tsv ../simulation_final/simu_K5_dep80_T4/sample2.tsv ../simulation_final/simu_K5_dep80_T4/sample3.tsv ../simulation_final/simu_K5_dep80_T4/sample4.tsv --working_dir  simu_K5_dep80_T4_samples --num_iters 10000 --burnin 6000 --seed 23




- run cloe on simulation datasets:

cd ./cloe/
R CMD BATCH -../simulation_final/simu_K3_dep40_T4/observed.Rdata-Reads-simu_K3_dep40_T4_samples-23 cloe_app.R simu_K3_dep40_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K3_dep60_T4/observed.Rdata-Reads-simu_K3_dep60_T4_samples-23 cloe_app.R simu_K3_dep60_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K3_dep80_T4/observed.Rdata-Reads-simu_K3_dep80_T4_samples-23 cloe_app.R simu_K3_dep80_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K4_dep40_T4/observed.Rdata-Reads-simu_K4_dep40_T4_samples-23 cloe_app.R simu_K4_dep40_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K4_dep60_T4/observed.Rdata-Reads-simu_K4_dep60_T4_samples-23 cloe_app.R simu_K4_dep60_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K4_dep80_T4/observed.Rdata-Reads-simu_K4_dep80_T4_samples-23 cloe_app.R simu_K4_dep80_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K5_dep40_T4/observed.Rdata-Reads-simu_K5_dep40_T4_samples-23 cloe_app.R simu_K5_dep40_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K5_dep40_T4_tree2/observed.Rdata-Reads-simu_K5_dep40_T4_tree2_samples-23 cloe_app.R simu_K5_dep40_T4_tree2_s23.txt
R CMD BATCH -../simulation_final/simu_K5_dep40_T4_tree3/observed.Rdata-Reads-simu_K5_dep40_T4_tree3_samples-23 cloe_app.R simu_K5_dep40_T4_tree3_s23.txt
R CMD BATCH -../simulation_final/simu_K5_dep60_T4/observed.Rdata-Reads-simu_K5_dep60_T4_samples-23 cloe_app.R simu_K5_dep60_T4_s23.txt
R CMD BATCH -../simulation_final/simu_K5_dep80_T4/observed.Rdata-Reads-simu_K5_dep80_T4_samples-23 cloe_app.R simu_K5_dep80_T4_s23.txt





II. reproduce real data results —————--------------------------------------------------------------------------------------------------------

cd ./SIFA/
Rscript SIFA_app.R -../data/BC_yates/PD9771/PD9771_input2.Rdata-Reads-PD9771_out_2_s23-23 2&>  PD9771_2_s23.txt 
Rscript SIFA_app.R -../data/BC_yates/PD9777/PD9777_input2.Rdata-Reads-PD9777_out_2_s23-23 2&>  PD9777_2_s23.txt 
Rscript SIFA_app.R -../data/BC_yates/PD9849/PD9849_input2.Rdata-Reads-PD9849_out_2_s23-23 2&>  PD9849_2_s23.txt 
Rscript SIFA_app.R -../data/BC_yates/PD9694/PD9694_input2.Rdata-Reads-PD9694_out_2_s23-23 2&>  PD9694_2_s23.txt 
